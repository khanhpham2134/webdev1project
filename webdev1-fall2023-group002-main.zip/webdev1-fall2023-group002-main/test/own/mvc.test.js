//describe: test suite
//it: test case
const chai = require('chai');

describe('Controllers', () => {
  describe('Products', () => {
    describe('async getAllProducts(response)', () => {
      it('should get all products', () => true)
    })
  })
  describe('Users', () => {
    describe('initialize the class', () => {
      it('should init the class', () => true)
    })
    describe('Test something', () => {
      it('should do something', () => true)
    })
    describe('Test something2', () => {
      it('should do something2', () => true)
    })
    describe('Test something3', () => {
      it('should do something3', () => true)
    })
    describe('Test something4', () => {
      it('should do something4', () => true)
    })
    describe('async getAllUsers(response)', () => {
      it('should get all users', () => true)
    })
    describe('async deleteUser(response, userId, currentUser)', () => {
      it('should delete user', () => true)
    })
    describe('async updateUser(response, userId, currentUser, userData)', () => {
      it('should update user', () => true)
    })
    describe('async viewUser(response, userId, currentUser)', () => {
      it('should view user', () => true)
    })
  })
})
  